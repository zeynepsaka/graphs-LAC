/*
 * Copyright (c) "Neo4j"
 * Neo4j Sweden AB [https://neo4j.com]
 *
 * This file is part of Neo4j.
 *
 * Neo4j is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package org.neo4j.io.pagecache;

/**
 * These callback implementations are produced by the page cache and given to the page swappers, so that the correct
 * translation tables can be updated when pages are evicted. The PageSwapper implementations are responsible for
 * delegating their {@link PageSwapper#evicted(long)} calls to these callback objects.
 */
public interface PageEvictionCallback {
    /**
     * Notify that the file/memory page has been evicted.
     */
    void onEvict(long filePageId);
}
